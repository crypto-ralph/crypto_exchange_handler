# crypto_exchange_handler

This library provides classes which can be used to access cryptocurrency exchanges from your code with unnified manner.

# License 
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

For the details refer to LICENSE.md